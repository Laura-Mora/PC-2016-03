//
//  funciones.hpp
//  Pilas & Colas
//
//  Created by Laura Juliana Mora on 3/11/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef funciones_hpp
#define funciones_hpp

#include <stdio.h>
#include <stack>
#include <queue>
struct compo{
    char vari;
    int prio;
};
using namespace std;
void prio(compo p[]);
#endif /* funciones_hpp */
