//
//  Funciones_caracteres.hpp
//  Cadenas caracteres
//
//  Created by Laura Juliana Mora on 25/08/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef Funciones_caracteres_hpp
#define Funciones_caracteres_hpp

#include <stdio.h>
#include <iostream>
using namespace std;
void invertir(char *pal);
#endif /* Funciones_caracteres_hpp */
