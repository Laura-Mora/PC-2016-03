//
//  FuncionesP3.hpp
//  Voltear recursion
//
//  Created by Laura Juliana Mora on 3/09/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef FuncionesP3_hpp
#define FuncionesP3_hpp

#include <stdio.h>
char *invertit (char *pal);
#endif /* FuncionesP3_hpp */
