//
//  Funciones.hpp
//  Histograma
//
//  Created by Laura Juliana Mora on 11/08/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef Funciones_hpp
#define Funciones_hpp

#include <stdio.h>
void crearvector(int *vec, int n);
void crearmatriz(int *vec, int n, char **m);
#endif /* Funciones_hpp */
