//
//  FuncionesNumerosAmigos.hpp
//  Nums amigos
//
//  Created by Laura Juliana Mora on 1/09/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef FuncionesNumerosAmigos_hpp
#define FuncionesNumerosAmigos_hpp

#include <stdio.h>
#include <iostream>
using namespace std;
int num(int numer, int acu, int cont);
#endif /* FuncionesNumerosAmigos_hpp */
