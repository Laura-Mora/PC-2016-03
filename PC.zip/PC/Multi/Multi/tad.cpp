//
//  tad.cpp
//  Multi
//
//  Created by Laura Juliana Mora on 12/10/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#include "tad.hpp"
