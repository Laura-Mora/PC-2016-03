//
//  tad.hpp
//  Multi
//
//  Created by Laura Juliana Mora on 12/10/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef tad_hpp
#define tad_hpp

#include <stdio.h>
struct Multilista{
    
};
#endif /* tad_hpp */
