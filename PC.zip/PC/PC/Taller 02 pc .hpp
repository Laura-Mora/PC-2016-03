//
//  Taller 02 pc .hpp
//  PC
//
//  Created by Laura Juliana Mora on 28/07/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef Taller_02_pc__hpp
#define Taller_02_pc__hpp

#include <stdio.h>

#endif /* Taller_02_pc__hpp */
