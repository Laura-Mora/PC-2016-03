//
//  funciones.hpp
//  Perrin
//
//  Created by Laura Juliana Mora on 3/08/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef funciones_hpp
#define funciones_hpp
void datos(int *,int);
void imprimir(int *,int);
int primos(int *,int );
int menu();
void imprimir2(int **p,int n);
void primos2(int *p,int n,int cant);
#endif /* funciones_hpp */
