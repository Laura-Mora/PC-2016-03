//
//  main.cpp
//  Suma nums
//
//  Created by Laura Juliana Mora on 1/09/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#include <iostream>
#include "Funciones p1.hpp"
using namespace std;
int main() {
    int num=0,num2=0;
    cin>>num;
    sum(num-1, num2+1);
    return 0;
}
