//
//  Funciones p1.hpp
//  Suma nums
//
//  Created by Laura Juliana Mora on 1/09/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef Funciones_p1_hpp
#define Funciones_p1_hpp

#include <stdio.h>
void sum(int num, int num2);
#endif /* Funciones_p1_hpp */
