//
//  Funciones hoja.hpp
//  Hoja de calculo
//
//  Created by Laura Juliana Mora on 21/08/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef Funciones_hoja_hpp
#define Funciones_hoja_hpp

#include <stdio.h>
#include <iostream>
void crear(char ***hojaInicial, int nfilas, int ncolumnas);
void CalcularHoja (char ***hojaInicial, int nfilas, int ncolumnas, int **hojaFinal);
#endif /* Funciones_hoja_hpp */
