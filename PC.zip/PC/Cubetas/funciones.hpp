//
//  funciones.hpp
//  Cubetas
//
//  Created by Laura Juliana Mora on 6/08/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef funciones_hpp
#define funciones_hpp

#include <stdio.h>
void crearvector(int *p, int cantidad, int dig);
void ordenar(int *p, int cantidad, int dig, int **m);
#endif /* funciones_hpp */
