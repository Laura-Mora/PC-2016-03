//
//  Funciones subcadena.hpp
//  Subcadena
//
//  Created by Laura Juliana Mora on 27/08/16.
//  Copyright © 2016 Laura Juliana Mora. All rights reserved.
//

#ifndef Funciones_subcadena_hpp
#define Funciones_subcadena_hpp
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
using namespace std;
int frasetam(char *frase);
bool subcadena (char *pal1, char *pal2);
#endif /* Funciones_subcadena_hpp */
